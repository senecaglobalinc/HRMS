import { Component, OnInit } from '@angular/core';
import { themeconfig } from 'themeconfig';
import { kradefindata } from '../krajson';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { AddKRAdlgComponent } from '../add-kradlg/add-kradlg.component';



@Component({
  selector: 'app-review-kra',
  templateUrl: './review-kra.component.html',
  styleUrls: ['./review-kra.component.scss']
})
export class ReviewKRAComponent implements OnInit {

  themeappeareance = themeconfig.formfieldappearances;
  displayedColumns: string[] = ['kraaspect', 'metrics', 'ration'];
  dataSource = kradefindata;

  importedKradisplayedColumns: string[] = ['select', 'kraaspect', 'metrics', 'ration'];
  selection = new SelectionModel<any>(true, []);

  addNewKRA: boolean = true;
  freezedKRA: boolean = false;
  importedKRA: boolean = false;

  marksAsFinish: boolean = false;
  undoBtn: boolean = false;
undoDiv:boolean=false;
deletedTr:boolean=false;
deletedKRAdiv:boolean=false;

  constructor(public dialog: MatDialog, public snackBar: MatSnackBar) { }

  ngOnInit() {
  }


  openAddKRA(e): void {
    if (e == 'add') {
      const dialogRef = this.dialog.open(AddKRAdlgComponent, {
        width: '80vw',
        data: { heading: 'Add KRA', btntext: 'Add' }
      });
      dialogRef.afterClosed().subscribe(result => {
        // this.importedKRA=result;
      });
    }
    else if (e == "edit") {
      const dialogRef = this.dialog.open(AddKRAdlgComponent, {
        width: '80vw',
        data: { heading: 'Edit KRA', btntext: 'Done' }
      });
      dialogRef.afterClosed().subscribe(result => {
        this.marksAsFinish = result;
      });
    }
  }

  dispUndo(){
    this.undoDiv=true;

   setTimeout(() => {
    this.undoDiv=false;
    this.undoBtn=true;
    this.marksAsFinish=true;
  }, 3000);

  }
  dispDelKRA(){
    this.deletedKRAdiv=true;

    setTimeout(() => {
      this.deletedKRAdiv=false;
    }, 3000);
  
  }

  deleteKRA(){
    this.deletedTr=true;
  }
}
