CREATE PROCEDURE [dbo].[usp_GetDepartmentsForExternal]  
AS  
BEGIN  
  
SET NOCOUNT ON;    
   
 SELECT  
   DepartmentId  
   ,DepartmentCode  
   ,Description  
 FROM   
  [dbo].[Departments]  
 WHERE IsActive = 1  
  
END