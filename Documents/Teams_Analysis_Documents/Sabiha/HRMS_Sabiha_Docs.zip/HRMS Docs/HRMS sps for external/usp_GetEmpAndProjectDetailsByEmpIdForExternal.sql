              
--use HRMSHotfix              
              
-- ====================================                
-- Author  : Sabiha                   
-- Create date  : 25-June-2020                        
-- Modified date:                
-- Modified By  :         
-- Description  : Draf version of the procedure to get employee and project details by empid.                   
              
/*              
AssociateId,              
First Name,              
Last Name,              
Gender,              
Email,              
EmployeeId,              
ProjectId,              
ProjectName,              
ClientId,              
ClientName,              
ReportingManagerId,              
ReportingManagerName,              
ProgramManagerId,              
ProgramManagerName,              
ApproverId,              
ApproverNo,              
ApproverName,              
DepartmentId,              
DepartmentName,              
EffectiveFromDate,              
EffectiveToDate,              
IsActive,              
Date of Joining              
Role,              
Designation,              
Scheme type              
*/              
-- ====================================              
CREATE procedure [dbo].[usp_GetEmpAndProjectDetailsByEmpIdForExternal]              
(                  
  @EmployeeId INT                  
 )          
as              
SELECT distinct              
employee.EmployeeCode as AssociateCode              
,employee.FirstName as [FirstName]              
,employee.LastName as  [LastName]        
,employee.FirstName + ' ' + employee.LastName as AssociateName              
,employee.Gender            
,(select distinct EmailAddress from Users users where users.UserId = employee.UserId) as Email              
,employee.EmployeeId as AssociateId              
,prj.ProjectId              
,prj.ProjectName              
,clients.ClientId              
,clients.ClientName              
,alloc.ReportingManagerID as ReportingManagerId              
,(select distinct firstname+' '+LastName from employee where EmployeeId=alloc.ReportingManagerID) as ReportingManagerName              
,PM.ProgramManagerID as ProgramManagerId      
,dbo.udfGetEmployeeFullName(PM.ProgramManagerID) AS ProgramManagerName          
,(select alloc.ProgramManagerID where alloc.ReleaseDate is null) as ProgramManagerId          
--,(select distinct firstname+' '+LastName from employee where EmployeeId=alloc.ProgramManagerID) as ProgramManagerName              
--,ra.ApprovedByID as ApproverId        
--,(select distinct firstname+' '+LastName from employee where EmployeeId=ra.ApprovedByID) as ApproverName              
,dept.DepartmentId              
,dept.description as DepartmentName              
,alloc.EffectiveDate as EffectiveFromDate              
,alloc.ReleaseDate as EffectiveToDate              
,employee.IsActive              
,employee.JoinDate as [Date of Joining]              
,rm.RoleDescription         
,desig.DesignationName as Designation    
,employee.isActive                
from [dbo].[Employee] employee    
inner join Departments dept on  employee.DepartmentId=dept.DepartmentId         
inner join Designations desig on desig.DesignationId=employee.Designation             
left join AssociateAllocation alloc on alloc.EmployeeId=employee.EmployeeId and alloc.isActive = 1 and alloc.isPrimary = 1         
left join Projects prj on prj.ProjectId=alloc.ProjectId               
left join Clients clients on prj.ClientId=clients.ClientId  and clients.IsActive=1          
left join ResignationApproval ra on employee.EmployeeId=ra.ApprovedByID             
left join RoleMaster rm on alloc.RoleMasterId=rm.RoleMasterID     
LEFT JOIN ProjectManagers PM ON alloc.ProjectId = PM.ProjectID AND PM.IsActive=1    
where employee.EmployeeId = @EmployeeId     
order by employee.EmployeeCode    
    
