-- =================================================        
-- Author   : Sabiha        
-- Create date  : 01-07-2020        
-- Modified date :         
-- Modified By  :         
-- Description  : Get Multiple EmpDetails By EmpIds    
-- =================================================        
        
CREATE PROCEDURE [dbo].[usp_GetMultipleEmpDetailsByEmpIdsForExternal]        
(        
@EmployeeIds varchar(500)        
)        
AS        
 BEGIN  
  
 IF OBJECT_ID('tempdb.dbo.#ResultTable') IS NOT NULL  
  DROP TABLE #ResultTable;  
   
  BEGIN  
  CREATE TABLE #ResultTable                                 
  (       
   Id INT IDENTITY(1,1),                         
   AssociateId INT,  
   AssociateName varchar(100),  
   isReportingLead bit                        
  )   
 END  
 IF(LEN(@EmployeeIds)>0)                                
 BEGIN                                                             
                                
  INSERT INTO #ResultTable (AssociateId,AssociateName)   
    
  SELECT e.EmployeeId, e.FirstName + ' ' + e.LastName from  Employee e where IsActive=1 AND e.EmployeeId in(SELECT * FROM dbo.CSVToTable(@EmployeeIds))  
  UPDATE #ResultTable SET isReportingLead = 0  
     
 END  
  
 --SELECT * from #ResultTable  
   
 IF OBJECT_ID('tempdb.dbo.#TempPMTable') IS NOT NULL  
  DROP TABLE #TempPMTable;  
   
  BEGIN  
  CREATE TABLE #TempPMTable                                 
  (       
   Id INT IDENTITY(1,1),                         
   EmpId INT,  
   PMName varchar(100),  
   isReportingLead bit                        
  )   
 END  
 IF(LEN(@EmployeeIds)>0)                                
 BEGIN                                                             
                                
  INSERT INTO #TempPMTable (EmpId,PMName)   
  EXEC [usp_GetManagersLeadsAndHeadsForExternal]  
  UPDATE #TempPMTable SET isReportingLead = 1  
     
 END  
  
 --SELECT * from #TempPMTable  
  
  
 BEGIN  
 UPDATE A SET A.isReportingLead = 1   
 from #ResultTable A  
  JOIN #TempPMTable B ON A.AssociateId = B.EmpId  
  where B.EmpId = A.AssociateId  
  
 END  
   
 --SELECT AssociateId,AssociateName,isReportingLead from #ResultTable where AssociateId in (@EmployeeIds)  
 --SELECT AssociateId,AssociateName,isReportingLead from #ResultTable where AssociateId in (1,152)  
 SELECT AssociateId,AssociateName,isReportingLead from #ResultTable  
END