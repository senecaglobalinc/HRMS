-- =================================================    
-- Author   : Sabiha    
-- Create date  : 30-06-2020    
-- Modified date :     
-- Modified By  :     
-- Description  : Get all the active employees by employeeid    
-- =================================================    
    
CREATE PROCEDURE [dbo].[usp_GetEmployeeNameByEmployeeIdForExternal]    
(    
@EmployeeId INT    
)    
AS    
BEGIN    
 SET NOCOUNT ON;    
    
 SELECT    
  [dbo].[udfGetEmployeeFullName](@EmployeeId) AS [Name]    
    
END    