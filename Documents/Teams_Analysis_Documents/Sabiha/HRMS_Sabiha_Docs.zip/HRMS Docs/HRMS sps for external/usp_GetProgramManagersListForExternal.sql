CREATE PROCEDURE [dbo].[usp_GetProgramManagersListForExternal]  
AS  
BEGIN  
 SET NOCOUNT ON;  
  
 --To get program Managers  
 SELECT DISTINCT  
   employee.EmployeeId AS ApproverId  
  ,employee.employeeCode AS ApproverCode  
  ,[dbo].[udfGetEmployeeFullName](employee.EmployeeId) AS ApproverName  
 FROM  
  [dbo].[ProjectManagers] projectManagers  
  INNER JOIN [dbo].[Employee] employee  
  ON projectManagers.ProgramManagerID = employee.EmployeeId  
 WHERE   
  projectManagers.IsActive = 1 AND employee.IsActive = 1 AND projectManagers.ProgramManagerID IS NOT NULL  
  ORDER BY ApproverName  
END  
  