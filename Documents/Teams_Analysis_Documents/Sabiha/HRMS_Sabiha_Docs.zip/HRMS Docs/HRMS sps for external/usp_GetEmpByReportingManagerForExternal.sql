CREATE procedure [dbo].[usp_GetEmpByReportingManagerForExternal]                
 (                    
  @RMId INT                    
 )             
as                
                
SELECT distinct                
employee.EmployeeCode as AssociateCode                
,employee.FirstName as FirstName               
,employee.LastName  as LastName       
,employee.FirstName + ' ' + employee.LastName as AssociateName                     
,(select distinct EmailAddress from Users users where users.UserId = employee.UserId) as Email                
,employee.EmployeeId as AssociateId                
,alloc.ReportingManagerID as ReportingManagerId                
,(select distinct firstname+' '+LastName from employee where EmployeeId=alloc.ReportingManagerID) as ReportingManagerName                
from [dbo].[Employee] employee                 
left join AssociateAllocation alloc on alloc.EmployeeId=employee.EmployeeId --and employee.IsActive=1                
               
where  alloc.IsActive=1 AND IsPrimary = 1 AND alloc.ReportingManagerId = @RMId             
order by employee.EmployeeCode 