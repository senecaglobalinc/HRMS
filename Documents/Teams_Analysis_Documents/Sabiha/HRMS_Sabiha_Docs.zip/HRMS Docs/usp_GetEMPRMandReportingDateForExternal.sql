-- =============================================      
-- Author:  Sabiha      
-- Create date: 28-Aug-2020     
-- Modified date: 03-Sep-2020    
-- Description:       
-- The purpose of this SP is to get Employee Code and his Reporting Manager EmployeeCode along with Joining Date.      
      
-- For Technology & Delivery Department, we will fetch from Employee table EmployeeCode and AssociateAllocation EmployeeCode and Joining Date.      
-- For Service Departments we will fetch from EMP table EmployeeCode and Reporting Manager EmployeeCode and Joining Date.      
      
-- =============================================                    
ALTER PROCEDURE [dbo].[usp_GetEMPRMandReportingDateForExternal]      
AS                
BEGIN          

SELECT 
employee.EmployeeCode AS [Employee Number], 
[dbo].[udfGetEmployeeCode](employee.ReportingManager) AS [Manager's Employee Number],
CASE WHEN CONVERT(VARCHAR(8), alloc.EffectiveDate, 1) IS NOT NULL THEN CONVERT(VARCHAR(8), alloc.EffectiveDate, 1) ELSE CONVERT(VARCHAR(8),employee.JoinDate,1) END  AS [Reporting From]
FROM [dbo].[Employee] employee  
LEFT JOIN AssociateAllocation alloc on  alloc.EmployeeId=employee.EmployeeId  AND alloc.IsActive=1 AND alloc.IsPrimary = 1              
WHERE employee.EmployeeId <> 1 AND  employee.IsActive=1
AND employee.EmployeeCode NOT LIKE 'u%' 
ORDER BY employee.EmployeeCode;
   
END